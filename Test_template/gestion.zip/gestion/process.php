<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['signup'])) {
        $nom = trim($_POST['nom']);
        $prenom = trim($_POST['prenom']);
        $adresse = trim($_POST['adresse']);
        $mot_de_passe = $_POST['mot_de_passe'];
        $confirm_mot_de_passe = $_POST['confirm_mot_de_passe'];

        if (empty($nom) || empty($prenom) || empty($adresse) || empty($mot_de_passe)) {
            echo "<p class='error'>Tous les champs sont obligatoires.</p>";
            exit;
        }

        if ($mot_de_passe !== $confirm_mot_de_passe) {
            echo "<p class='error'>Les mots de passe ne correspondent pas.</p>";
            exit;
        }

        echo "<p>Inscription réussie! Vous pouvez maintenant vous connecter.</p>";

    } elseif (isset($_POST['login'])) {
        $adresse = trim($_POST['adresse']);
        $mot_de_passe = $_POST['mot_de_passe'];

        if (empty($adresse) || empty($mot_de_passe)) {
            echo "<p class='error'>Adresse et mot de passe sont obligatoires.</p>";
            exit;
        }

        echo "<p>Connexion réussie! Bienvenue $adresse.</p>";
    }
}
