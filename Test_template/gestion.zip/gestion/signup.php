<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Styling for form container */
        .form-container {
            width: 90%;
            max-width: 400px;
            margin: 3rem auto;
            background: #515166;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
        }
        .form-container h2 {
            color: #FFFFFF;
            font-size: 1.8rem;
            text-align: center;
            margin-bottom: 1rem;
        }
        .form-container label {
            color: #FFFFFF;
            font-size: 1rem;
            margin-bottom: 0.5rem;
            display: block;
        }
        .form-container input[type="text"],
        .form-container input[type="password"] {
            width: 100%;
            padding: 0.75rem;
            margin-bottom: 1.5rem;
            border: 1px solid #737386;
            border-radius: 5px;
            background-color: #737386;
            color: #FFFFFF;
        }
        .form-container input[type="submit"] {
            width: 100%;
            padding: 0.75rem;
            background-color: #4CAF50;
            color: #FFFFFF;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-bottom: 1rem;
        }
        .form-container input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Inscription</h2>
        <form action="process.php" method="POST">
            <!-- Label for last name -->
            <label for="nom">Nom</label>
            <input type="text" name="nom" id="nom" placeholder="Votre nom" required>
            
            <!-- Label for first name -->
            <label for="prenom">Prénom</label>
            <input type="text" name="prenom" id="prenom" placeholder="Votre prénom" required>
            
            <!-- Label for email address -->
            <label for="adresse">Adresse e-mail</label>
            <input type="text" name="adresse" id="adresse" placeholder="Votre adresse e-mail" required>
            
            <!-- Label for password -->
            <label for="mot_de_passe">Mot de passe</label>
            <input type="password" name="mot_de_passe" id="mot_de_passe" placeholder="Créez un mot de passe" required>
            
            <!-- Label for confirm password -->
            <label for="confirm_mot_de_passe">Confirmez le mot de passe</label>
            <input type="password" name="confirm_mot_de_passe" id="confirm_mot_de_passe" placeholder="Confirmez le mot de passe" required>
            
            <input type="submit" name="signup" value="S'inscrire">
        </form>
    </div>
</body>
</html>
