from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Charger et entraîner le modèle
app = FastAPI()

df = pd.read_csv("dataR2.csv")
X = df.drop(columns=["Classification"])
y = df["Classification"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

modele_rf = RandomForestClassifier(n_estimators=100, random_state=42)
modele_rf.fit(X_train, y_train)

# Sauvegarder le modèle
joblib.dump(modele_rf, "modele_rf.pkl")

class InputData(BaseModel):
    Age: float
    BMI: float
    Glucose: float
    Insulin: float
    HOMA: float
    Leptin: float
    Adiponectin: float
    Resistin: float
    MCP_1: float  # Changement ici

@app.post("/predict")
def predict(data: InputData):
    try:
        df_input = pd.DataFrame([data.dict()])
        df_input.rename(columns={"MCP_1": "MCP.1"}, inplace=True)  # Harmonisation
        df_input = df_input[X_train.columns]  # Vérifier que les colonnes correspondent
        modele_rf = joblib.load("modele_rf.pkl")
        prediction = modele_rf.predict(df_input)
        return {"prediction": int(prediction[0])}
    except Exception as e:
        return {"error": str(e)}

@app.get("/accuracy")
def get_accuracy():
    modele_rf = joblib.load("modele_rf.pkl")
    y_pred = modele_rf.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    return {"accuracy": accuracy}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
