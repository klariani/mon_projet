<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire de Prédiction</title>
</head>
<body>
    <h2>Formulaire de Prédiction</h2>
    
    <form action="traite.php" method="post">
		Age: <input type="number" name="Age" required><br>
		BMI: <input type="number" name="BMI" required><br>
		Glucose: <input type="number" name="Glucose" required><br>
		Insulin: <input type="number" name="Insulin" required><br>
		HOMA: <input type="number" name="HOMA" required><br>
		Leptin: <input type="number" name="Leptin" required><br>
		Adiponectin: <input type="number" name="Adiponectin" required><br>
		Resistin: <input type="number" name="Resistin" required><br>
		MCP_1: <input type="number" name="MCP_1" required><br> <!-- Correction ici -->
		<button type="submit">Prédire</button>
	</form>


</body>
</html>
