import pymysql
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sqlalchemy import create_engine
from io import BytesIO
import base64

# Connexion à la base de données MySQL avec SQLAlchemy
conn = pymysql.connect(
    host='localhost',      # Modifier selon ton serveur
    user='root',           # Ton utilisateur
    password='root',   # Ton mot de passe
    database='risque'      # Nom de ta base de données
)


# Récupérer les données de la table 'datar2'
query = "SELECT Age, BMI, Glucose, Insulin, HOMA, Leptin, Adiponectin, Resistin, `MCP.1`, Classification FROM datar2;"
df = pd.read_sql(query, conn)
conn.close()

# Regrouper par 'Classification' et afficher la moyenne
gb = df.groupby('Classification')
print(gb.mean())

# Création de la matrice de corrélation
plt.figure(figsize=(10, 8))
sns.heatmap(df.corr(), annot=True, fmt=".2f", cmap="coolwarm", linewidths=0.5)
plt.title("Matrice de Corrélation des Variables")

# Sauvegarde en image base64 pour HTML
buffer = BytesIO()
plt.savefig(buffer, format='png')
plt.close()
encoded_image = base64.b64encode(buffer.getvalue()).decode('utf-8')

# Génération du HTML
html_code = f"""
<html>
<head><title>Corrélation</title></head>
<body>
    <h2>Matrice de Corrélation</h2>
    <img src='data:image/png;base64,{encoded_image}'/>
</body>
</html>
"""

# Sauvegarde en fichier HTML
with open("correlation.html", "w") as file:
    file.write(html_code)

print("Fichier HTML généré : correlation.html")
