<?php
// Récupérer les données envoyées par le formulaire
$age = $_POST['Age'];
$bmi = $_POST['BMI'];
$glucose = $_POST['Glucose'];
$insulin = $_POST['Insulin'];
$homa = $_POST['HOMA'];
$leptin = $_POST['Leptin'];
$adiponectin = $_POST['Adiponectin'];
$resistin = $_POST['Resistin'];
$mcp_1 = $_POST['MCP_1'];

// Données sous forme de tableau pour envoyer à l'API
$data = [
    'Age' => $age,
    'BMI' => $bmi,
    'Glucose' => $glucose,
    'Insulin' => $insulin,
    'HOMA' => $homa,
    'Leptin' => $leptin,
    'Adiponectin' => $adiponectin,
    'Resistin' => $resistin,
    'MCP_1' => $mcp_1,
];

// Convertir en JSON pour l'API
$json_data = json_encode($data);

// URL de l'API FastAPI
$api_url = 'http://127.0.0.1:8000/predict';

// Initialiser la session cURL
$ch = curl_init($api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

// Exécuter la requête cURL et récupérer la réponse
$response = curl_exec($ch);

// Vérifier les erreurs
if(curl_errno($ch)) {
    echo 'Erreur cURL : ' . curl_error($ch);
} else {
    // Décoder la réponse JSON
    $response_data = json_decode($response, true);
    
    // Afficher la prédiction
    echo "Prédiction : " . $response_data['prediction'];
}

// Fermer la session cURL
curl_close($ch);
?>
